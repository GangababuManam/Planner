<?php
/**
 * ANTRIQ theme functions.
 *
 * @package ANTRIQ
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function antriq_setup(): void {
	load_theme_textdomain( 'antriq', get_template_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'style.css' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array( 'height' => 96, 'width' => 360, 'flex-height' => true, 'flex-width' => true ) );
	register_nav_menus( array( 'primary' => esc_html__( 'Primary Menu', 'antriq' ) ) );
}
add_action( 'after_setup_theme', 'antriq_setup' );

function antriq_enqueue_assets(): void {
	$version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'antriq-style', get_stylesheet_uri(), array(), $version );
	wp_enqueue_script( 'antriq-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), $version, true );
}
add_action( 'wp_enqueue_scripts', 'antriq_enqueue_assets' );

function antriq_menu_classes( array $classes, $item, $args ): array {
	if ( 'primary' === $args->theme_location && false !== stripos( $item->title, 'Request a Demo' ) ) {
		$classes[] = 'menu-item-button';
	}
	return $classes;
}
add_filter( 'nav_menu_css_class', 'antriq_menu_classes', 10, 3 );

function antriq_register_pattern_category(): void {
	register_block_pattern_category( 'antriq-pages', array( 'label' => esc_html__( 'ANTRIQ Pages', 'antriq' ) ) );
}
add_action( 'init', 'antriq_register_pattern_category' );
