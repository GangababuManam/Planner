<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'antriq' ); ?></a>
<header class="site-header">
	<div class="site-branding">
		<?php if ( has_custom_logo() ) : ?>
			<?php the_custom_logo(); ?>
		<?php else : ?>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img class="custom-logo" src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/antriq-logo.jpeg' ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"></a>
		<?php endif; ?>
	</div>
	<button class="menu-toggle" aria-controls="primary-navigation" aria-expanded="false"><?php esc_html_e( 'Menu', 'antriq' ); ?></button>
	<nav id="primary-navigation" class="site-navigation" aria-label="<?php esc_attr_e( 'Primary navigation', 'antriq' ); ?>">
		<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'primary-menu', 'fallback_cb' => 'wp_page_menu' ) ); ?>
	</nav>
</header>
