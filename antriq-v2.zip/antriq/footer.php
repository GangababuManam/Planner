<footer class="site-footer">
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><strong>ANTR<span>I</span>Q</strong></a>
	<p><?php esc_html_e( 'AI-Native Trust, Risk & Intelligence Quotient', 'antriq' ); ?></p>
	<p>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> ANTRIQ</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
