=== ANTRIQ ===
Contributors: antriq
Tags: business, custom-logo, custom-menu, featured-images, full-width-template
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 7.4
Version: 1.0.0
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

ANTRIQ is a classic WordPress theme for AI security, risk, trust and threat exposure content.

== Installation ==

1. Zip the `antriq` directory, not its parent directory.
2. In WordPress, go to Appearance > Themes > Add New > Upload Theme.
3. Upload the zip and activate ANTRIQ.
4. Go to Appearance > Customize > Site Identity to upload the supplied ANTRIQ logo and Site Icon.
5. Create or edit pages under Pages. Set the required homepage under Settings > Reading.
6. Create the navigation under Appearance > Menus and assign it to Primary Menu.

== Content management ==

Every page body is managed in the WordPress editor. Add a new page in Pages > Add New and it inherits the theme automatically. The two ANTRIQ page patterns are available from the block inserter under ANTRIQ Pages.

For the three supplied ANTRIQ pages, create Home, AI Security Risk and Trust, and Threat Exposure Management pages. Copy their approved content from the supplied document into WordPress blocks and edit it normally from the page editor.

== Logo and site icon ==

The supplied ANTRIQ logo is included at `assets/images/antriq-logo.jpeg`. Upload it through Site Identity to use it as the editable site logo. Set a dedicated square Site Icon in Site Identity when one is available.
