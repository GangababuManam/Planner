# ANTRIQ WordPress v2

This is the CMS version of `html-template-v2`. It loads the original responsive styles, imagery, and animation assets without modification.

Create three WordPress Pages with these slugs: `home`, `ai-security-risk-trust`, and `threat-exposure-management`. Set Home as the static front page. Copy the body sections from the matching file in `starter-content/` into an HTML block on the matching WordPress Page; this preserves all approved content and original classes while allowing content updates in the editor.

Use Appearance > Menus for primary navigation and Appearance > Customize > Site Identity for the editable ANTRIQ logo.
