<?php get_header(); ?>
<main id="content" class="antriq-page"><div class="entry-content">
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>><h1 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1><?php the_excerpt(); ?></article>
	<?php endwhile; the_posts_navigation(); else : ?><p><?php esc_html_e( 'No content found.', 'antriq' ); ?></p><?php endif; ?>
</div></main>
<?php get_footer(); ?>
