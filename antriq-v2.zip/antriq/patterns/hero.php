<?php
/**
 * Title: Editorial hero
 * Slug: antriq/editorial-hero
 * Categories: antriq-pages
 * Description: A reusable dark ANTRIQ hero section for an editable page.
 */
?>
<!-- wp:html -->
<section class="antriq-hero">
  <p class="antriq-kicker">Add page category</p>
  <h1>Add your page headline.<br><em>Add an editorial emphasis.</em></h1>
  <p class="antriq-promise">Add your supporting promise.</p>
  <div class="antriq-two-column"><p>Add the first supporting paragraph.</p><p>Add the second supporting paragraph.</p></div>
</section>
<!-- /wp:html -->
