<?php
/**
 * Title: Two column copy
 * Slug: antriq/two-column-copy
 * Categories: antriq-pages
 * Description: A reusable two-column section for an editable ANTRIQ page.
 */
?>
<!-- wp:group {"className":"antriq-two-column"} -->
<div class="wp-block-group antriq-two-column"><!-- wp:paragraph --><p>Add the first column of content.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Add the second column of content.</p><!-- /wp:paragraph --></div>
<!-- /wp:group -->
